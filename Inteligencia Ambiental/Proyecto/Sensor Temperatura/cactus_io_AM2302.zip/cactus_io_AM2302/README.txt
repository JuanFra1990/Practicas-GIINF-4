This is an Arduino library for the AM2302 temperature/humidity sensors. 

Rename the uncompressed folder cactus_io_AM2302. Check that the DHT folder contains cactus_io_AM2302.cpp and cactus_io_AM2302.h. Place the DHT library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.
